function roundToTwo(num) 
{
    return +(Math.round(num + "e+2")  + "e-2");
}

function sum_dic( obj ) {
    var sum = 0;
    for( var el in obj ) {
      if( obj.hasOwnProperty( el ) ) {
        sum += parseFloat( obj[el] );
      }
    }
    return sum;
  }

function CarLoanCalculation(CarPrice, DownPrecent, Interest, Year)
{
    DownPayment = roundToTwo(CarPrice * (DownPrecent / 100));  //เงินดาวน์บาท
    Finance = roundToTwo(CarPrice - DownPayment); //ยอดจัดไฟแนนซ์ = นำราคารถ - เงินดาวน์
    Interest_To_Year = roundToTwo(Finance * (Interest / 100));  //ยอดรวมของดอกเบี้ย = นำยอดจัดไฟแนนซ์ x เปอร์เซ็นต์อัตราดอกเบี้ย

    Interest_All = roundToTwo( (Interest_To_Year+Finance) / Year); //ดอกเบี้ยทั้งหมดที่ต้องจ่าย = (ยอดรวมดอกเบี้ย + ยอดจัดไฟแนนซ์) / กับจำนวนปีที่ต้องการจะผ่อน)

    Price_All = roundToTwo(Finance + Interest_All);  //ยอดทั้งหมดที่ต้องจ่ายจริง = ยอดจัดไฟแนนซ์ + นำดอกเบี้ยทั้งหมดที่ต้องจ่าย 

    Pay_Per_Month = roundToTwo(Price_All / (Year * 12));  //ค่างวดในแต่ละเดือน = นำยอดทั้งหมดที่ต้องจ่ายจริง ÷ จำนวนเดือนที่ผ่อน (เช่น 24 เดือน หรือ 36 เดือน)

    console.log('------------ CarLoanCalculation ------------');
    console.log('เงินดาวน์: ', DownPayment);
    console.log('ยอดจัดไฟแนนซ์: ', Finance);
    console.log('ยอดรวมของดอกเบี้ย: ', Interest_To_Year);
    console.log('ดอกเบี้ยทั้งหมดที่ต้องจ่าย: ', Interest_All);
    console.log('ยอดทั้งหมดที่ต้องจ่ายจริง: ', Price_All);
    console.log('ค่างวดในแต่ละเดือน: ', Pay_Per_Month);
    console.log('--------------------------------------------')

    return [DownPayment, Finance, Interest_To_Year, Interest_All, Price_All, Pay_Per_Month];
}


function RegisFeeYear(CarSizeCC)
{
    // 1-600 CC = 0.5 สตางค์
    if (CarSizeCC > 600)
    {
        CC_SixHundred = 600 * 0.5;
    }
    else if (CarSizeCC <= 600)
    {
        CC_SixHundred = CarSizeCC * 0.5;
    }

    // 601-1800 CC = 1.5 บาท
    if ((CarSizeCC-600) > 0)
    {
        CC_ThousandEight = (CarSizeCC - 600) * 1.5;
    }
    else if ((CarSizeCC-600) <= 0)
    {
        CC_ThousandEight = 0;
    }

    // 1800 CC (Up) = 4 บาท
    if ((CarSizeCC-(600+1800)) > 0)
    {
        CC_ThousandEightUP = (CarSizeCC -(600+1800)) * 4;
    }
    else if ((CarSizeCC-(600+1800)) <= 0)
    {
        CC_ThousandEightUP = 0;
    }

    Price_RegisFeeYear = CC_SixHundred + CC_ThousandEight + CC_ThousandEightUP;


    console.log('-------------- RegisFeeYear ----------------');
    
    console.log('ขนาดรถ (CC): ', CarSizeCC);
    console.log('รวมภาษีทะเบียนรถ(ต่อทุกปี):' , Price_RegisFeeYear);

    Price_RegisFee_Month = roundToTwo(Price_RegisFeeYear / 12);
    console.log('รวมภาษีทะเบียนรถ(เฉลี่ยต่อเดือน):', Price_RegisFee_Month);


    // # ------ ตารางปี ---- #
    // # ปีที่ 1-5 จะคงที่ตามที่คำนวณได้
    // # เกิน 6 ปีขึ้นไปจะลดภาษีลง 10%
    Price_RegisFeeYearSix = roundToTwo(Price_RegisFeeYear - (Price_RegisFeeYear * (10/100)));

    // # ในปีที่ 10 ลดลงถึง 50% และคงที่ที่ 50% ในปีต่อไปเรื่อยๆ (ไม่แน่ใจ 50% ของปีแรก หรือ ของ 6ปี เลยใช้มากสุดที่ของปีแรก)
    Price_RegisFeeYearTen = Price_RegisFeeYear - (Price_RegisFeeYear * (50 / 100))
    Price_RegisFeeDic = {"1":Price_RegisFeeYear, "2":Price_RegisFeeYear, "3":Price_RegisFeeYear,
                        "4":Price_RegisFeeYear, "5":Price_RegisFeeYear,"6":Price_RegisFeeYearSix,
                        "7":Price_RegisFeeYearSix, "8":Price_RegisFeeYearSix, "9":Price_RegisFeeYearSix,
                        "10":Price_RegisFeeYearTen,"11":Price_RegisFeeYearTen,"12":Price_RegisFeeYearTen};

    // Price_RegisFeeDicSum = round(sum(Price_RegisFeeDic.values()), 2)
    Price_RegisFeeDicSum = roundToTwo(sum_dic(Price_RegisFeeDic));

    Price_RegisFeeDic['SUM'] = Price_RegisFeeDicSum;

    console.log('ตารางจ่ายภาษีทะเบียนรถรายปี: ', JSON.stringify(Price_RegisFeeDic));
    console.log('รวมจ่ายภาษีทะเบียนรถ 12 ปี: ', Price_RegisFeeDicSum);
    console.log('--------------------------------------------')

    return [Price_RegisFeeYear, Price_RegisFee_Month, Price_RegisFeeDic, Price_RegisFeeDicSum];
}

function PLB_Protection(TypeCAR='', SectionCAR='')
{
    Dic_TyprCar = {
        'รถยนต์โดยสาร': {
            'ที่นั่งไม่เกิน 7 รถเก๋ง':600, 'ที่นั่งไม่เกิน 15 รถตู้':1100, 'ที่นั่งไม่เกิน 20': 2050, 'ที่นั่งไม่เกิน 40': 3200, 'ที่นั่งเกิน 40': 3740
        },

        'รถกระบะ/รถบรรทุก': {
            'ไม่เกิน 3 ตัน(รถกระบะ)': 900, 'ไม่เกิน 6 ตัน': 1220, 'ไม่เกิน 12 ตัน': 1310,
            'ไม่เกิน 12 ตัน(บรรทุกเชื้อเพลิง)': 1680, 'เกิน 12 ตัน(บรรทุกเชื้อเพลิง)': 2320
        },

        'รถประเภทอื่นๆ': {
            'หัวรถลากจูง': 2370, 'รถพ่วง': 600, 'รถยนต์ที่ใช้ในการเกษตร': 90
        }
    };

    console.log('-------------- PLB_Protection ----------------');
    console.log(TypeCAR)
    console.log(SectionCAR)

    Price_TyprCar = Dic_TyprCar[TypeCAR][SectionCAR];
    console.log('ค่า พ.ร.บ. รายปี' + '(' + TypeCAR + SectionCAR + '): ', Price_TyprCar)
    console.log('--------------------------------------------')

    return Price_TyprCar;
}

function CarInsurance(TypeInsurance)
{
    Dic_Insurance = {'ประกันชั้น 1 (12,000)': 12000, 'ประกันชั้น 2 (6,000)': 6000, 'ประกันชั้น 3 (5,000)': 5000, 'ไม่ซื้อประกัน (0)': 0};

    console.log('-------------- CarInsuranc------------------')
    Price_CarInsurance = Dic_Insurance[TypeInsurance];
    console.log('ค่าประกันภัยรถยนต์ ' + TypeInsurance + ' รายปี: ', String(Price_CarInsurance))
    console.log('--------------------------------------------')

    return Price_CarInsurance;
}

function OilCost(Km_Liter, Price_Liter, Km_Mont)
{
    Price_Oli_Mont = roundToTwo((Km_Mont/Km_Liter) * Price_Liter);

    console.log('--------------- OilCost --------------------')
    console.log('รถใช้น้ำมัน กม./ลิตร: ', Km_Liter)
    console.log('Km_Mont: ', Price_Liter)
    console.log('ระยะทาง กม. ที่ใช้ ต่อ เดือน: ', Km_Mont)

    console.log('ค่าน้ำมันรายเดือน: ', Price_Oli_Mont)

    Price_Oli_year = roundToTwo(Price_Oli_Mont*12);
    console.log('ค่าน้ำมันรายปี: ', Price_Oli_year)
    console.log('--------------------------------------------')

    return [Price_Oli_Mont, Price_Oli_year];
}

function TirePrice(rim)
{
    dic_rim = {'ขอบยาง 13" (2,100)':2100, 'ขอบยาง 14" (2,200)':2200,'ขอบยาง 15" (2,300)':2300,'ขอบยาง 16" (4,000)':4000,'ขอบยาง 17" (6,000)':6000,
            'ขอบยาง 18" (8,000)':8000,'ขอบยาง 19" (10,000)':10000,'ขอบยาง 20" (11,000)':11000,'ขอบยาง 21" (15,000)':15000, 'โดยประมาณ (2,500)':2500,
            'ไม่คิดค่ายาง (0)':0};

    console.log('---------------- TirePrice -----------------')

    console.log(rim)

    rim_four_year = roundToTwo(dic_rim[rim] * 4)
    console.log('ค่าเปลี่ยนยาง 4 เส้น (4ปีครั้ง โดยประมาณ): ', rim_four_year)

    rim_year = roundToTwo( (dic_rim[rim]*4) / 4);
    console.log('ค่าเปลี่ยนยาง 4 เส้น (เฉลี่ยต่อปี): ', rim_year)

    rim_month = roundToTwo( (dic_rim[rim]*4) / (4*12) );
    console.log('ค่าเปลี่ยนยาง 4 เส้น (เฉลี่ยต่อเดือน): ', rim_month)
    console.log('--------------------------------------------')

    return [rim_four_year, rim_year, rim_month];
}

function OtherExpenses(Parking, Expressway, WashCar, CarInspection, TrafficFine)
{
    console.log('------------- OtherExpenses ---------------')
    console.log('ค่าที่จอดรถ (รายเดือน): ', Parking)
    console.log('ค่าทางด่วน (รายเดือน): ', Expressway)
    console.log('ค่าล้างรถ (รายเดือน): ', WashCar)

    console.log('ตรวจสภาพรถยนต์/ค่าตกแต่งรถ (รายปี): ', CarInspection)
    console.log('ตรวจสภาพรถยนต์/ค่าตกแต่งรถ (เฉลี่ยต่อเดือน): ', CarInspection/12)

    console.log('ค่าปรับที่ทำผิดกฎจราจร (รายปี): ', TrafficFine)
    console.log('ค่าปรับที่ทำผิดกฎจราจร (เฉลี่ยต่อเดือน): ', TrafficFine/12)

    OtherExpensesSum = roundToTwo( Parking + Expressway + WashCar + (CarInspection/12) + (TrafficFine/12) );
    console.log('รวมค่าใช้จ่ายอื่นๆ (รายเดือน): ', String(OtherExpensesSum))
    console.log('--------------------------------------------')

    return OtherExpensesSum;
}


function GetResults_CalCar(CarPrice, DownPrecent, Interest, Year, CarSizeCC,
    TypeCAR, SectionCAR, TypeInsurance,
    Km_Liter, Price_Liter, Km_Mont, rim,
    Parking, Expressway, WashCar,
    CarInspection, TrafficFine)
{

    CarLoanCalculation_out = CarLoanCalculation(CarPrice, DownPrecent, Interest, Year);
    DownPayment = CarLoanCalculation_out[0];
    Finance = CarLoanCalculation_out[1];
    Interest_To_Year = CarLoanCalculation_out[2];
    Interest_All = CarLoanCalculation_out[3];
    Price_All = CarLoanCalculation_out[4];
    Pay_Per_Month = CarLoanCalculation_out[5];

    RegisFeeYear_out = RegisFeeYear(CarSizeCC)
    Price_RegisFeeYear = RegisFeeYear_out[0];
    Price_RegisFee_Month = RegisFeeYear_out[1];
    Price_RegisFeeDic = RegisFeeYear_out[2];
    Price_RegisFeeDicSum = RegisFeeYear_out[3];

    Price_TyprCar = PLB_Protection(TypeCAR, SectionCAR)

    Price_CarInsurance = CarInsurance(TypeInsurance)

    OilCost_out = OilCost(Km_Liter, Price_Liter, Km_Mont)
    Price_Oli_Mont = OilCost_out[0];
    Price_Oli_year = OilCost_out[1];

    TirePrice_out = TirePrice(rim)
    rim_four_year = TirePrice_out[0];
    rim_year = TirePrice_out[1];
    rim_month = TirePrice_out[2];

    OtherExpensesSum = OtherExpenses(Parking, Expressway, WashCar, CarInspection, TrafficFine)

    Total_expenses_per_month = roundToTwo(
        Pay_Per_Month + Price_RegisFee_Month + (Price_TyprCar/12) + 
        (Price_CarInsurance/12) + Price_Oli_Mont + rim_month + OtherExpensesSum);

    return [DownPayment, Finance, Interest_To_Year, Interest_All, Price_All, Pay_Per_Month, Price_RegisFeeYear, Price_RegisFee_Month,
    Price_RegisFeeDic, Price_RegisFeeDicSum, Price_TyprCar, Price_CarInsurance, Price_Oli_Mont, Price_Oli_year,
    rim_four_year, rim_year, rim_month, OtherExpensesSum, Total_expenses_per_month];
}