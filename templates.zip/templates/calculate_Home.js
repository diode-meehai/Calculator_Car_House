// คำนวณการผ่อนซื้อบ้าน
var LoanAmount_globel;
var Pay_Per_Month_globel;
// คำนวณการผ่อนซื้อบ้าน

function roundToTwo(num) 
{
    return +(Math.round(num + "e+2")  + "e-2");
}

function sum_dic(obj) {
    var sum = 0;
    for( var el in obj ) {
      if( obj.hasOwnProperty( el ) ) {
        sum += parseFloat( obj[el] );
      }
    }
    return sum;
  }

function sum_list(total, num) {
  return total + num;
}

// # ========================= คำนวณการผ่อนซื้อบ้าน ========================= #

function PMT(ir, np, pv, fv, type) {
  /*
   * ir   - interest rate per month
   * np   - number of periods (months)
   * pv   - present value
   * fv   - future value
   * type - when the payments are due:
   *        0: end of the period, e.g. end of month (default)
   *        1: beginning of period
   */
  var pmt, pvif;

  fv || (fv = 0);
  type || (type = 0);

  if (ir === 0)
      return -(pv + fv)/np;

  pvif = Math.pow(1 + ir, np);
  pmt = - ir * (pv * pvif + fv) / (pvif - 1);

  if (type === 1)
      pmt /= (1 + ir);

  return pmt;
}

function DebtInstallment(Finance, Interest, Pay_Per_Month)
{
    Interest_All = [];  // ดอกเบี้ย ทั้งหมด
    Balance_month = [];  // ชำระเงินต้น ทั้งหมด
    Debt_start = Finance; // ยอดหนี้ เริ่มต้น
    DebtBalance_month = []; // ยอดหนี้เหลือ

    while (Debt_start >= 0)
    {
        Interest_month = ((Debt_start * (Interest / 100)) / 365) * 30;  // ชำระดอกเบี้ย
        Interest_All.push(roundToTwo(Interest_month));

        balance = Pay_Per_Month - Interest_month;  // ชำระเงินต้น
        Balance_month.push(roundToTwo(balance));

        Debt_start = roundToTwo(Debt_start - balance); // ยอดหนี้คงเหลือ
        //console.log('Debt_start: ', Debt_start)
        DebtBalance_month.push(roundToTwo(Debt_start));
    }

    Number_Years = parseInt( ((DebtBalance_month.length) - 1) / 12 );  //# จำนวนงวด
    return [Interest_All, Balance_month, DebtBalance_month, Number_Years];
}

function HomeLoanCalculation(LoanAmount, DownPrecent, Interest, Year)
{
  DownPayment = LoanAmount * (DownPrecent / 100);  // เงินดาวน์บาท
  DownPayment = roundToTwo(DownPayment);

  Finance = LoanAmount - DownPayment; // ยอดจัดไฟแนนซ์
  Finance = roundToTwo(Finance);

  // PMT(ดอกเบี้ยต่อปี /12, งวด(เดือน), ยอดเงินกู้)
  // Pay_Per_Month = - (npf.pmt((Interest / 100) / 12, Year * 12, Finance, 000))  // ค่างวดในแต่ละเดือน (PMT)
  // Pay_Per_Month = round(Pay_Per_Month, 2)
  Pay_Per_Month = -PMT((Interest / 100) / 12, Year * 12, Finance).toFixed(2);

  // ชำระดอกเบี้ย , ชำระเงินต้น, ยอดหนี้คงเหลือ, จำนวนปีผ่อนชำระหมด
  DebtInstallment_out= DebtInstallment(Finance=Finance,Interest=Interest, Pay_Per_Month=Pay_Per_Month);
  Interest_All_list = DebtInstallment_out[0];
  Balance_month_list = DebtInstallment_out[1];
  DebtBalance_month_list = DebtInstallment_out[2];
  Number_Years = DebtInstallment_out[3];

  // Interest_All_list = 0;
  // Balance_month_list = 0;
  // DebtBalance_month_list = 0;
  // Number_Years = 0;

  // self.LoanAmount = LoanAmount
  // self.Pay_Per_Month = Pay_Per_Month
  LoanAmount_globel  = LoanAmount;
  Pay_Per_Month_globel = Pay_Per_Month;

  console.log('------------ CarLoanCalculation ------------')
  console.log('เงินดาวน์: ', DownPayment)
  console.log('ยอดจัดไฟแนนซ์: ', Finance)
  console.log('ดอกเบี้ย: ', Interest)
  console.log('จำนวนปีที่กู้: ', Year)
  console.log('ค่างวดในแต่ละเดือน: ', Pay_Per_Month)

  console.log('ดอกเบี้ยทั้งหมดที่ต้องจ่าย: ', Interest_All_list)
  console.log('ชำระเงินต้น: ', Balance_month_list)
  console.log('ยอดหนี้คงเหลือ: ', DebtBalance_month_list)
  console.log('จำนวนปีผ่อนชำระหมด: ', Number_Years)
  console.log('--------------------------------------------')

  return [DownPayment, Finance, Pay_Per_Month, Interest_All_list, Balance_month_list, DebtBalance_month_list, Number_Years]
}
// # ========================= คำนวณการผ่อนซื้อบ้าน ========================= #

// # ========================= คำนวณความสามารถผ่อนชำระ ========================= #
// # Debt Service Ratio ความสามารถผ่อนชำระหนี้ (มากก็ดี)
function DebtServiceRatio(salary, DebtMonth)
{
    DSR_out = salary / DebtMonth
    DSR_out = roundToTwo(DSR_out)
    return DSR_out
}

// salary, jobType='พนักงานประจำ', DebtCredit=10000, OtherMonthly_Debt=0
function SalaryLoan(salary, jobType, DebtCredit, OtherMonthly_Debt)
{

  DebtCredit_Cal = DebtCredit * 0.1;  // คิด 10%
  DebtCredit_Cal = roundToTwo(DebtCredit_Cal);

  career_type = {'พนักงานประจำ': 1, 'เจ้าของกิจการ(คนเดียว)': 0.1, 'เจ้าของกิจการ(หจก.)': 0.1, 'อาชีพอิสระ': 0.5};

  // # ------- สูตร แบ่งประเภทรายได้ และ คิดลบค่าใช้จ่ายจริง ------- #
  salary_type = salary * career_type[jobType];  //# คิด % รายได้ ตามประเภทงาน
  salary_expenses = salary_type * 0.7;  //# รายได้ ลบ ค่าใช้จ่ายในชีวิตประจำวัน 30% เหลือ 70% ของรายได้
  salary_Max_Month = salary_expenses - (OtherMonthly_Debt + DebtCredit_Cal);  //# รายได้ ลบภาระหนี้สินต่อเดือน = ภาระหนี้ที่สามารถผ่อนจ่ายต่อเดือนได้
  LoanAmount_Max = salary_Max_Month * (1000 / 7);  //# ล้านละ 7 พัน

  // # ------- สูตร Sansiri (รายได้หักค่าใช้จ่าย * วงเงินกู้ / ขั้นต่ำต่องวดที่ต้องชำระ) ------- #
  // LoanAmount_Sansiri = (salary_Max_Month * self.LoanAmount) / self.Pay_Per_Month;
  LoanAmount_Sansiri = (salary_Max_Month * LoanAmount_globel) / Pay_Per_Month_globel;

  // # ------- สูตร คิดลบค่าใช้จ่ายทั่วไป โดยประมาณ ------- #
  salary_Min_Month = salary_type * 0.4;  //# ภาระหนี้ที่สามารถผ่อนจ่ายต่อเดือนได้ - รายจ่าย 60% เหลือ 40% ของรายได้
  LoanAmount_Min = salary_Min_Month * (1000 / 7);  //# ล้านละ 7 พัน

  console.log('------------ SalaryLoan ------------')
  console.log('รายรับ: ', salary)
  console.log('รายจ่าย: ', (OtherMonthly_Debt + DebtCredit_Cal))

  DSR_out = DebtServiceRatio(salary=salary, DebtMonth=roundToTwo(DebtCredit + OtherMonthly_Debt))
  console.log('DSR ความสามารถผ่อนชำระหนี้ (มากก็ดี ~3): ', DSR_out)

  salary_Max_Month = roundToTwo(salary_Max_Month)
  console.log('ภาระหนี้ที่สามารถผ่อนจ่ายต่อเดือนได้ (หักค่าใช้จ่ายจริง): ', salary_Max_Month)

  LoanAmount_Max = roundToTwo(LoanAmount_Max)
  console.log('วงเงินที่กู้ได้ (หักค่าใช้จ่ายจริง): ', LoanAmount_Max)

  salary_Min_Month = roundToTwo(salary_Min_Month)
  console.log('ภาระหนี้ที่สามารถผ่อนจ่ายต่อเดือนได้ (หักค่าใช้จ่าย 40% ของรายได้): ', salary_Min_Month)

  LoanAmount_Min = roundToTwo(LoanAmount_Min)
  console.log('วงเงินที่กู้ได้ (หักค่าใช้จ่าย 40% ของรายได้): ', LoanAmount_Min)

  LoanAmount_Sansiri = roundToTwo(LoanAmount_Sansiri)
  console.log('วงเงินที่กู้ได้ (หักค่าใช้จ่าย เทียบวงเงินกู้ที่ต้องชำระขั้นต่ำต่อเดือน): ', LoanAmount_Sansiri)
  console.log('------------------------------------')

  return [DSR_out, salary_Max_Month, LoanAmount_Max, salary_Min_Month, LoanAmount_Min, LoanAmount_Sansiri]
}

// # ========================= คำนวณความสามารถผ่อนชำระ ========================= #

// # ========================= คำนวณค่าใช้จ่ายขายบ้าน ========================= #
// # บัญชีอัตราภาษีเงินได้ สำหรับบุคคลธรรมดา
function IncomeTaxRateAccount(Average_Netincome_year, YearHolding)
{
    TaxRate_per = [];
    price_list = [100000, 500000, 1000000, 4000000, 4000001];
    price_per = [0.05, 0.1, 0.2, 0.3, 0.37];
    balance = Average_Netincome_year;

    // for i, price in enumerate(price_list):
    for (const [i, price] of price_list.entries())
    {
      if ( (balance - price) > 0 && i < 4 )
      {
          TaxRate = price * price_per[i];
          TaxRate_per.push(TaxRate);
          balance = balance - price;
      }

      else if ( (balance - price) > 0 && i == 4 )
      {
          TaxRate = (balance - price) * price_per[i];
          TaxRate_per.push(TaxRate);
          balance = balance - (balance - price);
      }

      else
      {
          TaxRate = balance * price_per[i];
          TaxRate_per.push(TaxRate);
          balance = 0;
      }
        
    }
    //console.log('TaxRate_per: ', TaxRate_per)

    sum_list_out = TaxRate_per.reduce(sum_list)
    //console.log('sum_list_out: ', sum_list_out)

    TaxRate_all_year = YearHolding * sum_list_out;
    //console.log('sum_list: ', TaxRate_all_year)
    return [TaxRate_per, TaxRate_all_year]
}

// # ค่าลดหย่อนตามปีที่ถือครอง
function DeductibleYear(YearHolding)
{
    Deductible_Year_tex_dic = {1: 0.92, 2: 0.84, 3: 0.77, 4: 0.71, 5: 0.65, 6: 0.60, 7: 0.55, 8: 0.50};
    if (YearHolding >= 8)
    {
        Deductible_Year_tex = Deductible_Year_tex_dic[8];
    }
    else
    {
        Deductible_Year_tex = Deductible_Year_tex_dic[YearHolding];
    }

    return Deductible_Year_tex
}

function PurchaseCost(SellingPrice, PriceDepartment, YearHolding, YearNameHouse, Corporation)
{
    console.log('Corporation: ', Corporation)
    // # อาจมีการเปลี่ยนแปลงตามนโยบายภาครัฐ

    // # ค่าโอน 2% (ราคาประเมินกรมที่ดิน), อาจแบ่งจ่ายคนละครึ่ง
    Transfer_fee = PriceDepartment * 0.02;

    // # ค่าจดจำนอง 1% ของยอดเงินกู้จากธนาคาร(60%ราคาบ้าน)
    Mortgage = (SellingPrice * 0.6) * 0.01;

    Stamp_duty = 0;  //# ค่าอากรแสตมป์
    BusinessTax = 0;  //# ค่าภาษีธุรกิจเฉพาะ

    console.log('YearHolding', YearHolding)
    console.log('YearNameHouse', YearNameHouse)

    //# ค่าภาษีธุรกิจเฉพาะ 3.3% (นิติบุคลลเสียตลอด)
    if ( Corporation == 'true' || (YearHolding < 5 && YearNameHouse < 1 ))
    {
        console.log('Corporation Fase = นิติบุคลล')
        if (SellingPrice < PriceDepartment)
        {
            BusinessTax = SellingPrice * 0.033;
        }
        else
        {
            BusinessTax = PriceDepartment * 0.033;
        }
    }

    //# ค่าอากรแสตมป์ 0.5% (ราคาประเมินที่มากสุด) ถือครอง > 5 ปี หรือ ชื่อในโฉนด > 1
    //# elif YearHolding >= 5 or YearNameHouse >= 1:
    else
    {
        console.log('Corporation else = บุคคลธรรมดา')
        if ( SellingPrice < PriceDepartment )
        {
            Stamp_duty = SellingPrice * 0.005;
        }
        else
        {
            Stamp_duty = PriceDepartment * 0.005;
        }
    }



    //# ค่าภาษีเงินได้
    //# ค่าลดหย่อนตามปีที่ถือครอง
    Deductible_Year_tex = DeductibleYear(YearHolding);

    Discount_Year = PriceDepartment * Deductible_Year_tex;  //# ลดหย่อนตามปี (ราคาประเมิน)
    Netincome_Discount = PriceDepartment - Discount_Year;  //# เงินได้สุทธิ-ลดหย่อน (ราคาประเมิน)
    Average_Netincome_year = Netincome_Discount / YearHolding;  //# เงินได้สุทธิเฉลี่ยตามปี

    IncomeTaxRateAccount_out = IncomeTaxRateAccount(Average_Netincome_year, YearHolding);
    TaxRate_per = IncomeTaxRateAccount_out[0];
    TaxRate_all_year = IncomeTaxRateAccount_out[1];

    console.log('------------ PurchaseCost ------------')
    console.log('ราคาขาย: ', SellingPrice)
    console.log('ราคาประเมินกรมที่ดิน: ', PriceDepartment)
    console.log('ถือครองมา(ปี) เจ้าของบ้าน: ', YearHolding)
    console.log('มีชื่อในโฉนด (ปี) เจ้าบ้าน: ', YearNameHouse)
    console.log('สถานะนิติบุคคล: ', Corporation)
    console.log('-----')

    Transfer_fee = roundToTwo(Transfer_fee);
    console.log('ค่าโอน 2% (ราคาประเมินกรมที่ดิน): ', Transfer_fee)

    Mortgage = roundToTwo(Mortgage);
    console.log('ค่าจดจำนอง 1% ของยอดเงินกู้จากธนาคาร(60%ราคาบ้าน): ', Mortgage)

    Stamp_duty = roundToTwo(Stamp_duty);
    console.log('ค่าอากรแสตมป์ 0.5% (ราคาประเมินที่มากสุด) ถือครอง > 5 ปี หรือ ชื่อในโฉนด > 1: ', Stamp_duty)

    BusinessTax = roundToTwo(BusinessTax);
    console.log('ค่าภาษีธุรกิจเฉพาะ 3.3% (นิติบุคลลเสียตลอด): ', BusinessTax)

    Deductible_Year_tex = roundToTwo(Deductible_Year_tex); //# *
    console.log('% ลดหย่อนตามปีที่ถือครอง: ', Deductible_Year_tex)

    Discount_Year = roundToTwo(Discount_Year);
    console.log('ค่าลดหย่อนตามปีที่ถือครอง (ราคาประเมิน): ', Discount_Year) //# *

    Netincome_Discount = roundToTwo(Netincome_Discount);
    console.log('เงินได้สุทธิ-ลดหย่อน คงเหลือ (ราคาประเมิน): ', Netincome_Discount) //# *

    Average_Netincome_year = roundToTwo(Average_Netincome_year);
    console.log('ภาษีเงินได้เฉลี่ยต่อปี (ปีที่ถือครอง): ', Average_Netincome_year) //# *

    // TaxRate_per = TaxRate_per;
    console.log('เทียบตาราง ภาษีเงินได้ที่ต้องชำระ (คูณปีที่ถือครอง): ', TaxRate_per)  //# *

    TaxRate_all_year = roundToTwo(TaxRate_all_year);
    console.log('ภาษีเงินได้ที่ต้องชำระ (คูณปีที่ถือครอง): ', TaxRate_all_year)

    
    Sum_Price = roundToTwo(Transfer_fee + Mortgage + Stamp_duty + BusinessTax + TaxRate_all_year);
    console.log('ค่าใช้จ่ายรวม: ', Sum_Price)
    console.log('--------------------------------------')

    return [Transfer_fee, Mortgage, Stamp_duty, BusinessTax, Deductible_Year_tex, Discount_Year, Netincome_Discount,Average_Netincome_year, TaxRate_per, TaxRate_all_year, Sum_Price]
}
// # ========================= คำนวณค่าใช้จ่ายขายบ้าน ========================= #